# Ansible Collection - some_dummy_er2341.dummy_collection

Dummy collection for demonstartion purpose only
